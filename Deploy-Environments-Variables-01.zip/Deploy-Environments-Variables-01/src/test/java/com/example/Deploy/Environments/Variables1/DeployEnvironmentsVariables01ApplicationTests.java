package com.example.Deploy.Environments.Variables1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeployEnvironmentsVariables01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
